package taskagitmakas;

import java.util.Random;
import java.util.Scanner;

public class TasKagitMakas {
    public static void main(String[] args) {
        String[] tasKagitMakas = {"taş","kağıt","makas"};
        int skorPlayer = 0;
        int skorBilgisayar = 0;
        System.out.println("**********Taş Kağıt Makas Oyunu**********");
        System.out.println("Ad:");        
        Scanner scanner = new Scanner(System.in);
        
        String oyuncuAd = scanner.nextLine();

        //Oyun
        while (skorPlayer != 3 && skorBilgisayar != 3) {
            System.out.println("**************************\n"
                             + "Taş: t\n"
                             + "Kağıt: k\n"
                             + "Makas: m\n"
                             + "**************************");
            String hamle = scanner.nextLine();
            String txt = "";
            if(hamle.equals("t")){
                txt = "Taş";
            }
            else if(hamle.equals("k")){
                txt = "Kağıt";
            }
            else if(hamle.equals("m")){
                txt = "Makas";
            }
            else{
                System.out.println("Geçersiz seçim");
            }
            
            String random = tasKagitMakas[new Random().nextInt(tasKagitMakas.length)];
            
            System.out.println("Seçimin: " + txt);
            System.out.println("Bilgisayarın seçimi: " + random);        
        
            if(hamle.equals("t")) {
            if(random.equals("taş")) {
                System.out.println("Berabere.");
            }
            else if(random.equals("kağıt")) {
                System.out.println("Bilgisayara +1 puan.");
                skorBilgisayar += 1;
            }
            else{
                System.out.println(oyuncuAd + " adlı oyuncuya +1 puan.");
                skorPlayer += 1;               
            }
        }
        
        if(hamle.equals("k")) {
            if(random.equals("taş")) {
                System.out.println(oyuncuAd + " adlı oyuncuya +1 puan.");
                skorPlayer += 1;
            }
            else if(random.equals("kağıt")) {
                System.out.println("Berabere.");
            }
            else{
                System.out.println("Bilgisayara +1 puan.");
                skorBilgisayar += 1;                
            }
        }
        
        if(hamle.equals("m")) {
            if(random.equals("taş")) {
                System.out.println("Bilgisayara +1 puan.");
                skorBilgisayar += 1;               

            }
            else if(random.equals("kağıt")) {
                System.out.println(oyuncuAd + " adlı oyuncuya +1 puan.");
                skorPlayer += 1;
            }
            else{
                System.out.println("Berabere.");
            }
        }
        }
        if(skorBilgisayar == 3) System.out.println("Bilgisayar Kazandı.");
        else if(skorPlayer == 3) System.out.println(oyuncuAd +" kazandı.");
        
        System.out.println("Puanın: " + skorPlayer);
        System.out.println("Bilgisayarın Puanı: " + skorBilgisayar);
    }
}