package atm;

public class Banka{
    
    public static void main(final String[] args) {
        final Hesap can = new Hesap("Can", "B00001");
        can.menuGoster();
    }
}