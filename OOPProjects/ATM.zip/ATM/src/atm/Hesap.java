package atm;

import java.util.Scanner;
import java.util.Arrays;

public class Hesap
{
    int bakiye;
    int[] gecmis;
    String kullaniciAd;
    String kullaniciID;
    
    Hesap(final String cname, final String cid) {
        this.gecmis = new int[0];
        this.kullaniciAd = cname;
        this.kullaniciID = cid;
    }
    
    void paraYatir(final int tutar) {
        if (tutar != 0) {
            this.bakiye += tutar;
            (this.gecmis = Arrays.copyOf(this.gecmis, this.gecmis.length + 1))[this.gecmis.length - 1] = tutar;
        }
    }
    
    void paraCek(final int tutar) {
        if (this.bakiye < tutar) {
            System.out.println("Yetersiz bakiye.");
        }
        else {
            this.bakiye -= tutar;
            (this.gecmis = Arrays.copyOf(this.gecmis, this.gecmis.length + 1))[this.gecmis.length - 1] = -tutar;
        }
    }
    
    void getGecmisIslem() {
        System.out.println("-İşlemler-\n");
        for (int i = 0; i < this.gecmis.length; ++i) {
            if (this.gecmis[i] > 0) {
                System.out.println("Para yatırma: " + this.gecmis[i] + "TL");
            }
            else if (this.gecmis[i] < 0) {
                System.out.println("Para çekme: " + this.gecmis[i] + "TL");
            }
        }
    }
    
    void faizHesapla(final int yillar) {
        final double faizMiktari = 0.0225;
        final double newbakiye = this.bakiye * faizMiktari * yillar + this.bakiye;
        System.out.println("şuanki artış" + 100.0 * faizMiktari + "%");
        System.out.println(String.valueOf(yillar) + " Yıl sonraki bakiye: " + newbakiye);
    }
    
    void menuGoster() {
        char option = '\0';
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Hosgeldin " + this.kullaniciAd);
        System.out.println("Kullanıcı ID: " + this.kullaniciID);
        System.out.println();
        System.out.println("Yapılacak İşlem: ");
        System.out.println();
        System.out.println("A. Bakiye ögrenme");
        System.out.println("B. Para yatirma");
        System.out.println("C. Para cekme");
        System.out.println("D. Islem gecmisi");
        System.out.println("E. Faiz hesaplama");
        System.out.println("F. Çıkış");
        do {
            System.out.println();
            System.out.println("Islem: ");
            final char option2 = scanner.next().charAt(0);
            option = Character.toUpperCase(option2);
            System.out.println();
            switch (option) {
                case 'A': {
                    System.out.println("====================================");
                    System.out.println("bakiye: " + this.bakiye);
                    System.out.println("====================================");
                    System.out.println();
                    continue;
                }
                case 'B': {
                    System.out.println("Yatırılacak tutar: ");
                    final int tutar = scanner.nextInt();
                    this.paraYatir(tutar);
                    System.out.println();
                    continue;
                }
                case 'C': {
                    System.out.println("Çekilecek tutar: ");
                    final int tutar2 = scanner.nextInt();
                    this.paraCek(tutar2);
                    System.out.println();
                    continue;
                }
                case 'D': {
                    System.out.println("====================================");
                    this.getGecmisIslem();
                    System.out.println("====================================");
                    System.out.println();
                    continue;
                }
                case 'E': {
                    System.out.println("Kaç yıl?: ");
                    final int yillar = scanner.nextInt();
                    this.faizHesapla(yillar);
                    continue;
                }
                case 'F': {
                    System.out.println("====================================");
                    continue;
                }
                default: {
                    System.out.println("Geçersiz işlem.");
                    continue;
                }
            }
        } while (option != 'F');
        System.out.println("Görüşmek Üzere.");
    }
}